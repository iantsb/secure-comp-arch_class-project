# Releases

## Release v1.0.0
This release make the implementation of the sha256 core that have
existed for many years official. It indicates that the core is (and
has been for a long time) ready to use. The release will also make it
easier to separate future changes, updates.
